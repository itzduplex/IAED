/* Nome: Goncalo Nuno Branco Gaspar Antunes
   Numero: 93716                            */


#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_CHAR 64
#define SALAS 10
#define EVENTOS 100
#define MAX_GUEST 4

#define GUEST_PRINT "Impossivel adicionar participante. Participante %s tem um evento sobreposto.\n"
#define ROOM_PRINT "Impossivel agendar evento %s. Sala%d ocupada.\n"
#define GUEST_ROOM_PRINT "Impossivel agendar evento %s. Participante %s tem um evento sobreposto.\n"
#define EVENT_PRINT "Evento %s inexistente.\n"
#define GUEST_OVERLOAD_PRINT "Impossivel adicionar participante. Evento %s ja tem 3 participantes.\n"
#define GUEST_LONELY_PRINT "Impossivel remover participante. Participante %s e o unico participante no evento %s.\n"

typedef struct Evento
{
    char descricao[MAX_CHAR], participante[MAX_GUEST][MAX_CHAR];
    int inicio, duracao, fim, sala, guests;
    long int data;
}Evento;

Evento calendario[SALAS][EVENTOS];

/* Um evento não existe se a sua duracao for 0, logo, esta funcao inicializa todos os eventos de todas as salas com duracao 0, de modo
a que eles nao existam.*/

void cleanCalendar()
{
    int i, e;
    for (i = 0; i < SALAS; i++)
    {    
        for (e = 0; e < EVENTOS ; e++)
            calendario[i][e].duracao = 0;
    }
}

/*A funcao verifica se um evento de uma dada sala e indice existe, ou seja, se a sua duracao e diferente de 0.*/

int noEvent(int sala, int evento)
{
    return calendario[sala][evento].duracao == 0; 
}

/* A funcao  recebe um array de pointers e uma string, e "separa" a string de qualquer '\n' e ':' até que a mesma seja nula. */

void parseInput(char s[], char *p[])
{
    char *token;
    int i = 0;
    token = strtok(s, ":\n");

    for (i = 0; i < 9; i++)
    {    
        p[i] = token;
        token = strtok(NULL, ":\n");
    }
}

/* A funcao converte um tempo em horas e minutos para apenas minutos. */

int hourToMin(int hour)
{
    return ((hour / 100) * 60) + (hour % 100);
}

/*A funcao verifica dos eventos todos e retorna o indice do primeiro evento livre. */

int freeSlot(int room)
{
    int i;
    
    for (i = 0; i < EVENTOS; i++)
    {
        if (noEvent(room, i))
            return i;
    }

    return -1;
}

/* A funcao compara a data de dois eventos, comecando pelo ano, depois mes e por fim dia. */

int compareDate(Evento a, Evento b)
{
    int ano_a = a.data % 10000, ano_b = b.data % 10000, mes_a, mes_b, dia_a = a.data, dia_b = b.data;

    dia_a = dia_a / 10000;
    dia_b = dia_b / 10000;

    mes_a = dia_a % 100;
    mes_b = dia_b % 100;

    dia_a = dia_a / 100;
    dia_b = dia_b / 100;
    
    if (a.duracao == 0 || b.duracao == 0)  /* Trocam-se indices de eventos nao existentes. */
        return 1;
    
    if (ano_a > ano_b)                    /* Verifica-se sequencialmente o ano, o mes, o dia e posteriormente a hora inicial de cada evento. */
        return 1;

    if (ano_a == ano_b)
    {
        if (mes_a > mes_b)
            return 1;
        
        if (mes_a == mes_b)
        {
            if (dia_a > dia_b)
                return 1;
            
            if (dia_a == dia_b)
            {
                if (hourToMin(a.inicio) > hourToMin(b.inicio))
                    return 1;

                else if (hourToMin(a.inicio) == hourToMin(b.inicio))
                {
                    if (a.sala > b.sala)
                        return 1;  
                }  
            }    
        }
    }

    return 0;
}

/* A funcao verifica se dois eventos diferentes acontecem a horas diferentes, se tal acontecer devolve 1. Caso o inverso aconteca, devolve 0. */

int compareTime(Evento a, Evento b)
{
    int a_st, a_end, b_st, b_end;

    a_st = hourToMin(a.inicio);
    a_end = a_st + a.duracao;

    b_st = hourToMin(b.inicio);
    b_end = b_st + b.duracao;

    if (a.data != b.data)                   /* So faz sentido verificar colisoes de tempo se a data for igual. */
        return 1;

    if ((a_st < b_end && b_st < a_st) || (b_st < a_end && b_end > a_end) || (a_st <= b_st && a_end >= b_end) || 
    (a_st == b_st && a_end == b_end) || (a_st > b_st && a_end < b_end))             /* Caso alguma destas condicoes se verifique, ha colisao de tempo. */
        return 0;
    
    return 1;
}

/* A funcao recebe uma descricao de um evento, procura em todas as salas por esse mesmo evento e coloca na memória o indice da sala e do evento
para mais tarde ser acedido. Devolve 1 se o evento existir, e 0 se o inverso acontecer. */

int findEvent(char desc[], int *sala, int *evento)
{
    int i, j;
    for (i = 0; i < SALAS; i++)
    {
        for (j = 0; j < EVENTOS; j++)
        {
            if (noEvent(i, j))                                              /* Se o evento com indice de sala i e de evento j tiver duracao 0, incrementa-se uma unidade no for loop. */
                continue;
            
            if (!strcmp(calendario[i][j].descricao, desc))                  /* Se existir o evento com descricao dada, coloca o indice da sala e do evento na memoria e devolve 1. */
            {
                *sala = i;
                *evento = j;
                return 1;
            }
                
        }
    }
    return 0;
}

/* A funcao recebe uma sala, e imprime todos os eventos que existam nessa sala. Verifica se os participantes sao apenas 1, 2 ou 3, de modo a nao imprimir 
espacos em branco. Nao devolve nada. */


/* A funcao recebe um evento, circula pela lista de todos os eventos na mesma sala que o evento recebido e verifica se existem "overlaps" de tempo.
Se tais existirem, incrementa uma unidade a flag. Se essa flag for alguma vez incrementada, ou seja, houve pelo menos um overlap, a funcao devolve 0, caso 
contrario devolve 1. */

int roomFree(Evento a)
{
    int j, flag = 0;
    
    for (j = 0; j < EVENTOS; j++)
    {
        if (noEvent(a.sala, j))                                             /* Se o evento de indice j nao existir, incrementa-se 1 no for loop. */
            continue;
        
        if (!strcmp(calendario[a.sala][j].descricao, a.descricao))          /* As descricoes nao podem ser iguais, nao se podem comparar eventos iguais. */
            continue;

        if (!compareTime(calendario[a.sala][j], a))                         /* Se houver colisao de tempo, e porque as outras condicoes se verificaram, e incrementa-se 1 a flag. */
            flag++;
    }

    if (flag)
        return 0;
    return 1;   
}

/* A funcao recebe um evento, verifica se todos os participantes estao livres, circulando por todos os eventos em todas as salas, e comparando
todos os eventos com o recebido. Se algum dos participantes do evento a adicionar estiver noutro evento, e esse evento decorre a mesma hora que 
o que se pretende adicionar, incrementa-se uma unidade a flag. Caso a flag seja diferente de 0, ou seja, foi-lhe incrementada pelo menos uma unidade,
a funcao devolve 0. Caso contrario devolve 1. Tambem imprime erros consoante o participante que se encontra noutro evento ao mesmo tempo. */

int allGuestsFree(Evento a)
{
    int i, j, e, flag = 0;

    for (i = 0; i < SALAS; i++)
    {   
        for (j = 0; j < EVENTOS; j++)
        {            
            if (noEvent(i, j))
                continue;
            
            for (e = 0; e < a.guests; e++)
            {
                if (!compareTime(calendario[i][j], a) && strcmp(calendario[i][j].descricao, a.descricao) /* Verifica se o participante e valido ao mesmo tempo que existe uma colisao */                   
                    && a.participante[e][0] != '\0' && !strcmp(calendario[i][j].participante[0], a.participante[e]))  /* de eventos, para todos os participantes de um evento a adicionar. */
                {
                    printf(GUEST_ROOM_PRINT, a.descricao, a.participante[e]);
                    flag++;
                }

                if (!compareTime(calendario[i][j], a) && strcmp(calendario[i][j].descricao, a.descricao) 
                && a.participante[e][0] != '\0' && !strcmp(calendario[i][j].participante[1], a.participante[e]))
                {
                    printf(GUEST_ROOM_PRINT, a.descricao, a.participante[e]);
                    flag++;
                }

                switch (calendario[i][j].guests) /* Tem que se ter atencao ao numero de participantes de cada evento, nao se pode fazer comparacoes com participantes "nulos" */
                {
                    case (3):
                        if (!compareTime(calendario[i][j], a) && strcmp(calendario[i][j].descricao, a.descricao) 
                        && a.participante[e][0] != '\0' && !strcmp(calendario[i][j].participante[2], a.participante[e]))
                        {
                            printf(GUEST_ROOM_PRINT, a.descricao, a.participante[e]);
                            flag++;
                        }
                        break;

                    case (4):
                        if (!compareTime(calendario[i][j], a) && strcmp(calendario[i][j].descricao, a.descricao) 
                        && a.participante[e][0] != '\0' && !strcmp(calendario[i][j].participante[2], a.participante[e]))
                        {
                            printf(GUEST_ROOM_PRINT, a.descricao, a.participante[e]);
                            flag++;
                        }

                        if (!compareTime(calendario[i][j], a) && strcmp(calendario[i][j].descricao, a.descricao) 
                        && a.participante[e][0] != '\0' && !strcmp(calendario[i][j].participante[3], a.participante[e]))
                        {
                            printf(GUEST_ROOM_PRINT, a.descricao, a.participante[e]);
                            flag++;
                        }
                        break;
                }
            }
        }
    }
    
    if (flag)
        return 0;
    return 1;

}

/* A funcao recebe uma string de caracteres, retira-lhe quaisquer "\n" e ":" de modo a poder dar assign aos semi-elementos de cada evento, verifica se a sala
do evento a adicionar se encontra livre a hora pretendida e se os participantes nao se encontram em outro evento em simultaneo. Caso ambas estas coisas acontecam,
coloca o evento na variavel global, Evento calendario[sala][evento]. Caso uma das condicoes nao se verifique, imprime o pretendido erro. */

void addEvent(char s[])
{
    char *p[1000];
    Evento a;
    int i;
    a.guests = 0;
    parseInput(s, p);

    strcpy(a.descricao, p[0]);
    a.data = atoi(p[1]);
    a.inicio = atoi(p[2]);
    a.duracao = atoi(p[3]);
    a.sala = atoi(p[4]) - 1;

    for (i = 0; i < MAX_GUEST; i++)                             /* Se os participantes existem, colocam-se nos respetivos slots, caso contrario, o primeiro indice deles sera \0. */
    {
        if (p[i + 5] == NULL)
            a.participante[i][0] = '\0';
            
        else
        {
            strcpy(a.participante[i], p[i + 5]);
            a.guests++;
        }
    }
         
    if (!roomFree(a))                               /* Verifica-se se a sala esta livre. */
    {
        printf(ROOM_PRINT, a.descricao, a.sala + 1);
        return;
    }

    if (!allGuestsFree(a))                          /* Verifica-se se todos os participantes estao livres. */
        return;

    for (i = 0; i < EVENTOS; i++)                   /* Encontra-se o primeiro indice livre para colocar o evento a adicionar. */
    {
        if (!noEvent(a.sala, i))
            continue;

        calendario[a.sala][i] = a;
        return;
    }

    
    
}


/* A funcao recebe o numero de uma sala, circula por todos os eventos existentes nessa sala e troca a ordem deles se uma das coisas se verificar: A data do evento
anterior for superior a do evento posterior ou se a data de ambos os eventos for igual e o evento anterior acontecer depois do evento posterior. */

void sortByRoom(char s[])
{
    int i, sala, j;
    char *p[1000];
    Evento a;

    parseInput(s, p);
    sala = atoi(p[0]) - 1;
     
    for (i = 1; i < EVENTOS; i++)                           /* Algoritmo de Insertion Sort de modo a organizar todos os eventos da sala fornecida. */
    {
        a = calendario[sala][i]; 
        j = i - 1; 
        
        while (j >= 0 && compareDate(calendario[sala][j], a)) 
        { 
            calendario[sala][j + 1] = calendario[sala][j]; 
            j = j - 1; 
        } 
        calendario[sala][j + 1] = a; 
    }

    for (i = 0; i < EVENTOS; i++)
    {  
        if (noEvent(sala, i))                           /* Circula-se por eventos que existam e imprimem-nos. */
            continue;

        printf("%s %08ld %04d %d Sala%d %s\n* %s",calendario[sala][i].descricao, calendario[sala][i].data, calendario[sala][i].inicio,  
        calendario[sala][i].duracao, calendario[sala][i].sala + 1, calendario[sala][i].participante[0], calendario[sala][i].participante[1]);

        switch (calendario[sala][i].guests)
        {
            case (2):
                printf("\n");
                break;
        
            case (3):
                printf(" %s\n", calendario[sala][i].participante[2]);
                break;
            case (4):
                printf(" %s %s\n", calendario[sala][i].participante[2], calendario[sala][i].participante[3]);
                break;

        }           
    }

}

/* A funcao recebe uma string de caracteres contendo a o evento a apagar, se tal evento existir, coloca a sua duracao a 0: identificador que permite distinguir
eventos existentes de nao existentes. Se o evento nao existe, imprime mensagem de erro. */

void deleteEvent(char s[])
{
    int i, sala, evento;
    char *p[1000], desc[MAX_CHAR];
    Evento a;
    
    parseInput(s, p);
    
    strcpy(desc, p[0]);


    if (findEvent(desc, &sala, &evento))                                /* Se se encontrar o evento a apagar, coloca-se a duracao desse evento a 0 e coloca-se o ultimo evento */
    {                                                                   /* na posicao onde o evento a apagar estava. */
        calendario[sala][evento].duracao = 0;

        i = freeSlot(sala);

        a = calendario[sala][evento];
        calendario[sala][evento] = calendario[sala][i];
        calendario[sala][i] = a;
        return;
    }

    printf(EVENT_PRINT, desc);

}

/* A funcao cria um array temporario, onde coloca todos os eventos de todas as salas, e organiza cronologicamente todos os eventos. Se o evento tiver a mesma hora,
organiza em ordem crescente de sala. */

void sortEverything()
{
    Evento array[1000], a;
    int i, j, events = 0;

    for (i = 0; i < SALAS; i++)                                         /* Coloca-se todos os eventos com duracao diferente de 0 num array com 1000 (eventos) de dimensao. */
    {
        for (j = 0; j < EVENTOS; j++)
        {
            if (noEvent(i,j))
                continue;
            
            array[events++] = calendario[i][j];
        }
    }

    for (i = 1; i < events; i++)                                    /* Algoritmo de Insertion Sort para organizar o array temporario. */
    {
        a = array[i]; 
        j = i - 1; 
        
        while (j >= 0 && compareDate(array[j], a)) 
        { 
            array[j + 1] = array[j]; 
            j = j - 1; 
        } 
        array[j + 1] = a; 
    }

    for (i = 0; i < events; i++)
    {  
        if (array[i].duracao == 0)                                  /* Apenas se imprime eventos que tenham duracao diferente de 0, ou seja, que existem. */
            continue;
            
        printf("%s %08ld %04d %d Sala%d %s\n* %s", array[i].descricao, array[i].data, array[i].inicio, 
        array[i].duracao, array[i].sala + 1, array[i].participante[0], array[i].participante[1]);

        switch (array[i].guests)
        {
            case (2):
                printf("\n");
                break;
        
            case (3):
                printf(" %s\n", array[i].participante[2]);
                break;
            case (4):
                printf(" %s %s\n", array[i].participante[2], array[i].participante[3]);
                break;
        }     
    }
}

/* A funcao recebe um tempo inicial a alterar a um evento pre-existente e uma descricao, verifica se esse evento existe, se existir cria uma versao alterada e verifica se pode colocar o evento
alterado na estrutura global. Caso possa, coloca-o. */

void changeStartingTime(char s[])
{
    char *p[1000], desc[MAX_CHAR];
    int st_time, sala, evento;
    Evento a;
    
    parseInput(s, p);

    strcpy(desc, p[0]);
    st_time = atoi(p[1]);

    if (!findEvent(desc, &sala, &evento))               /* Se nao se encontrar o evento devolve-se mensagem de erro. */
    {
        printf(EVENT_PRINT, desc);
        return;
    }

    a = calendario[sala][evento];
    a.inicio = st_time;                                 /* Altera-se o tempo inicial da copia do evento encontrado e verifica-se se o mesmo nao entra em conflituo com outros eventos. */

    if (!roomFree(a))
    {
        printf(ROOM_PRINT, a.descricao, a.sala + 1);
        return;
    }   

    if (!allGuestsFree(a))
        return;

    calendario[a.sala][evento] = a;                     /* Coloca-se o evento na matriz, exatamente no mesmo slot em que o outro se encontrava. */
}
 

/* Tal como a funcao que altera o tempo inicial, a funcao recebe uma descricao e uma duracao, verifica se o evento com a descricao dada existe, se existir vai-lhe provisoriamente alterar a duracao
e verifica se o pode colocar na estrutura global. Se nao quebrar as condicoes da sala livre e dos participantes livres, coloca-o na sala. */

void changeDuration(char s[])
{
    char *p[1000], desc[MAX_CHAR];
    int duration, sala, evento;
    Evento a;
    
    parseInput(s, p);

    strcpy(desc, p[0]);
    duration = atoi(p[1]);

    if (!findEvent(desc, &sala, &evento))
    {
        printf(EVENT_PRINT, desc);
        return;
    }    

    a = calendario[sala][evento];
    a.duracao = duration;                       /* Altera-se a duracao da copia do evento. */

    if (!roomFree(a))
    {
        printf(ROOM_PRINT, a.descricao, a.sala + 1);
        return;
    }

    if (!allGuestsFree(a))
        return;
                
    
    calendario[a.sala][evento] = a;
    
}

/* Semelhante as ultimas duas funcoes, a funcao que altera a sala recebe uma sala e uma descricao, verifica se o evento com a descricao dada existe e se existir vai-lhe alterar a sala. Caso
nao entre em conflituo com outros eventos pre-existentes, coloca o evento com a sala alterada na estrutura global e tira o evento na sala anterior da mesma. */

void changeRoom(char s[])
{
    char *p[1000], desc[MAX_CHAR];
    int room, i, sala, evento;
    Evento a;
    
    parseInput(s, p);

    strcpy(desc, p[0]);
    room = atoi(p[1]) - 1;

    if (!findEvent(desc, &sala, &evento))
    {
        printf(EVENT_PRINT, desc);
        return;
    }
    
    a = calendario[sala][evento];
    a.sala = room;
    
    if (!roomFree(a))
    {
        printf(ROOM_PRINT, a.descricao, a.sala + 1);
        return;
    }

    if (!allGuestsFree(a))
        return;
 
    
        
    calendario[sala][evento].duracao = 0;                           /* Apaga-se o evento da outra sala, e procura-se o proximo slot livre da sala a colocar o evento alterado. */
    
    for (i = 0; i < EVENTOS; i++)
    {
        if (noEvent(a.sala, i))
        {
            calendario[a.sala][i] = a;  
            return;      
        }
    }
        
}

/* A funcao recebe uma descricao, verifica se o evento com a descricao dada existe, verifica se pode adicionar o participante ao evento: se o evento tiver 3 participantes, devolve erro, se
o participante tiver noutro evento em simultaneo, devolve erro. */

void addGuest(char s[])
{
    char *p[1000], desc[MAX_CHAR], part[MAX_CHAR];
    int sala, i, j, evento;

    parseInput(s, p);

    strcpy(desc, p[0]);
    strcpy(part, p[1]);

    if (!findEvent(desc, &sala, &evento))
    {   
        printf(EVENT_PRINT, desc);
        return;
    }
    
    if (calendario[sala][evento].guests == 4)
    {
        printf(GUEST_OVERLOAD_PRINT, desc);
        return;
    }

    for (i = 0; i < SALAS; i++)
    {        
        for (j = 0; j < EVENTOS; j++)
        {
            if (noEvent(i, j))
                continue;

            if (!strcmp(calendario[sala][evento].participante[0], part) || !strcmp(calendario[sala][evento].participante[1], part) ||
            !strcmp(calendario[sala][evento].participante[2], part) || !strcmp(calendario[sala][evento].participante[3], part))    /* Se o participante for igual a algum previamente colocado */
                return;                                                                                                             /* nao se faz nada. */

            if (strcmp(calendario[i][j].participante[0], part) && strcmp(calendario[i][j].participante[1], part) &&
            strcmp(calendario[i][j].participante[2], part) && strcmp(calendario[i][j].participante[3], part)) /* Se os participante a adicionar nao coincidir com nenhum dos do calendario */
                continue;                                                                                     /* incrementa-se um no for loop. */
            
            if (!compareTime(calendario[i][j], calendario[sala][evento]))      /* Se houver colisoes de tempo entre o evento a testar e qualquer outro evento da matriz */
            {                                                                  /* e porque o participante a adicionar se encontra noutro evento, logo, imprime-se erro */
                printf(GUEST_PRINT, part);
                return;
            }
                
        }
    }

    switch (calendario[sala][evento].guests)                                    /* Adiciona-se os participante no slot mais a direita. */
    {
        case (2):
            strcpy(calendario[sala][evento].participante[2], part);            
            calendario[sala][evento].guests++;
            return;
    
        case(3):
            strcpy(calendario[sala][evento].participante[3], part);
            calendario[sala][evento].guests++;
            return;
    }
}     

/* A funcao, tal como a que adiciona um participante, recebe uma descricao e um evento, verifica se o evento com a descricao dada existe: se nao existir, devolve erro. Verifica o evento so tem um
participante, se tal acontecer, devolve erro. Ao remover, desloca os participantes para as posicoes mais a esquerda. */

void removeGuest(char s[])
{
    char *p[1000], desc[MAX_CHAR], part[MAX_CHAR];
    int sala, evento;

    parseInput(s, p);

    strcpy(desc, p[0]);
    strcpy(part, p[1]);

    if (!findEvent(desc, &sala, &evento))
    {
        printf(EVENT_PRINT, desc);
        return;
    }

    if (strcmp(calendario[sala][evento].participante[1], part) && strcmp(calendario[sala][evento].participante[2], part) &&
    strcmp(calendario[sala][evento].participante[3], part))
        return;

    if (calendario[sala][evento].guests == 2)
    {
        printf(GUEST_LONELY_PRINT, calendario[sala][evento].participante[1], desc);
        return;
    }

    if (!strcmp(calendario[sala][evento].participante[1], part))                                /* Removem-se os participantes e deslocam-se todos uma unidade para a esquerda. */
    {
        strcpy(calendario[sala][evento].participante[1], calendario[sala][evento].participante[2]);
        strcpy(calendario[sala][evento].participante[2], calendario[sala][evento].participante[3]);
        calendario[sala][evento].participante[3][0] = '\0';
        calendario[sala][evento].guests--;
        return;
    }

    if (!strcmp(calendario[sala][evento].participante[2], part))
    {
        strcpy(calendario[sala][evento].participante[2], calendario[sala][evento].participante[3]);
        calendario[sala][evento].participante[3][0] = '\0';
        calendario[sala][evento].guests--;
        return;
    }

    if (!strcmp(calendario[sala][evento].participante[3], part))
    {
        calendario[sala][evento].participante[3][0] = '\0';
        calendario[sala][evento].guests--;
        return;
    }
}

/* O main da funcao inicializa a variavel global vazia e entra num loop infinito a pedir comandos até que seja pressionada a tecla x. */

int main()
{

    char command[1000];
    cleanCalendar();


    while (1)
    {
        switch((command[0] = getchar()))        /* Recebe-se a primeira letra do comando. */
        {
                case 'a':
                getchar();                      /* Anula-se o espaco produzido pela frase inserida. */
                fgets(command, 1000, stdin);    /* Recebe-se a frase util para a funcao. */
                addEvent(command);
                break;
            
            case 'l':
                sortEverything();
                break;
            
            case 's':
                getchar();
                fgets(command, 1000, stdin);
                sortByRoom(command);
                break;
            
            case 'r':
                getchar();
                fgets(command, 1000, stdin);
                deleteEvent(command);
                break;
            
            case 'i':
                getchar();
                fgets(command, 1000, stdin);
                changeStartingTime(command);
                break;
            
            case 't':
                getchar();
                fgets(command, 1000, stdin);
                changeDuration(command);
                break;

            case 'm':
                getchar();
                fgets(command, 1000, stdin);
                changeRoom(command);
                break;
            
            case 'A':
                getchar();
                fgets(command, 1000, stdin);
                addGuest(command);
                break;

            case 'R':
                getchar();
                fgets(command, 1000, stdin);
                removeGuest(command);
                break;

            case 'x':
                return 0;

        }
    
    }
    return 0;
}